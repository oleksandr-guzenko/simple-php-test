

<?php


require("inc/dbconnect.php");

if(isset($_POST['submit']))
{
$name=$_POST['name'];
$email=$_POST['email'];
$bank=$_POST['bank'];
$acct=$_POST['bankaccount'];
$transfer_amount=$_POST['transfer_amount'];
$status=$_POST['status'];
$pin=$_POST['pin'];
echo $acct;

$insertdata="INSERT INTO chief(name,email,bank,bank_account,transfer_amount,pin,status,date)
VALUES('$name','$email','$bank','$acct','$transfer_amount','$pin','$status',now())";
$theresults=mysqli_query($conn,$insertdata);
if($theresults==true)
{
header("location:success.php");
}
else {

echo "data failed";
}

}
else
{
header("location:new-account.php");
}
?>