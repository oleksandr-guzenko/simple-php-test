<?php
session_start();
if(isset($_SESSION['user']))
{
    header("location:new-account.php");
}
?>

<html>
<head>
<title>
login
</title>
<h2>login</h2>

<form action="inc/login-process.php"method="POST">
<input type="email"name="email"placeholder="enter email"required>
<input type="password"name="password"placeholder="enter password"required>
<input type="submit"name="submit">
</form>
</html>