<?php

$servername="localhost";
$dbusername="nenstudio_chief";
$dbpassword="carolinausd@C";
$dbname="nenstudio_chief";
$conn=mysqli_connect($servername,$dbusername,$dbpassword,$dbname);
if(!$conn)
{
die("connection failed:".mysqli_connect_error());

}
else
{
echo "you are connected";}
?>