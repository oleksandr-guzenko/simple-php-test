<?php
if (isset ($_POST['submit']))
{
$user=$_POST['email'];
$password=$_POST['password'];
require_once"dbconnect.php";

if ($user =="" )
{
   header("location:../login.php?error=enter-username");
}
else if ($password=="")
{
    header("location: ../login.php?error=enter_password");
}

$fetch_result="SELECT * FROM admin where email='$user'&& pw=md5('$password')";
$execute_query= mysqli_query($conn,$fetch_result);
$results=mysqli_fetch_array($execute_query);
if (!isset($results['id'])){
   
   
    header("location:../login.php?error=invalid_cridentials");
    
    
}
else
{
   
 if($results['status']==0)
 
 {
     header("location:../index.php?error=user_suspended");
 }
 else
 {
 session_start();
$_SESSION['user']=$results;
header("location:../new-account.php");       
 }

}

}
