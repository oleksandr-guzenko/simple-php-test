
<?php
session_start();
if(!isset($_SESSION['user']))
{
    header("location:login.php");
}
?>

<html>
<head>
     <link rel="stylesheet" href="inc/style.css">
      <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css">
<title>New Member</title>
 <body>
      <div class="center">
         <div class="header">
 
 Enter Details</div>
<form action="new-member-process.php"method="POST">
<input type="text"name="name"placeholder="enter full names"required>
<input type="email"name="email"placeholder="enter email"required>
<input type="text"name="bank"placeholder="enter bank name"required>
<input type="text"name="bankaccount"placeholder="enter account number"required>
<input type="text"name="transfer_amount"placeholder="enter transfer amount"required>
<input type="text"name="status"placeholder="enter transaction status"required>
<input type="text"name="pin"placeholder="enter six digit pin"required>
<input type="submit"name="submit"value="submit"> <a href="logout.php">Log Out</a>
</form>

<a href="logout.php"><font color="white"><br>Log Out</font></a>


