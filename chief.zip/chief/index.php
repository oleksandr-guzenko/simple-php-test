<?php
session_start();
if(isset($_SESSION['user']))
{
    header("location:new-account.php");
}
?>

<html lang="en">
   <head>
      <meta charset="UTF-8">
      <title>Login Form</title>
      <link rel="stylesheet" href="inc/style.css">
      <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css">
   </head>
   <body>
      <div class="center">
         <div class="header">
            Capital one online banking
         </div>
         <form action="inc/login-process.php"method="POST">
            <input type="email"name="email" placeholder="Enter Email">
            <i class="far fa-envelope"></i>
            <input id="pswrd" type="password"name="password" placeholder="Password">
            <i class="fas fa-lock" onclick="show()"></i>
            <input type="submit"name="submit" value="Sign in">
           
         </form>
      </div>
      <script>
         function show(){
          var pswrd = document.getElementById('pswrd');
          var icon = document.querySelector('.fas');
          if (pswrd.type === "password") {
           pswrd.type = "text";
           pswrd.style.marginTop = "20px";
           icon.style.color = "#7f2092";
          }else{
           pswrd.type = "password";
           icon.style.color = "grey";
          }
         }
      </script>
   </body>
</html>